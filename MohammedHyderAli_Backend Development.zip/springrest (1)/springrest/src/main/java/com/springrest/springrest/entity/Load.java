package com.springrest.springrest.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Loaddetails")
public class Load {

	@Column(name = "Loading_Point")
	private String Loadingpoint;
	@Column(name = "Unloading_Point")
	private String Unloadingpoint;
	@Column(name = "Product_Type")
	private String ProductType;
	@Column(name = "Truck_Type")
	private String TruckType;
	@Column(name = "No_Of_Trucks")
	private long NoOfTrucks;
	@Column(name = "Weight")
	private long Weight;
	@Column(name = "Description")
	private String Description;
	@Id
	private long ShipperID;
	@Column(name = "Date")
	private String Date;
	public Load(String loadingpoint, String unloadingpoint, String productType, String truckType, long noOfTrucks,
			long weight, String description, long shipperID, String date) {
		super();
		Loadingpoint = loadingpoint;
		Unloadingpoint = unloadingpoint;
		ProductType = productType;
		TruckType = truckType;
		NoOfTrucks = noOfTrucks;
		Weight = weight;
		Description = description;
		ShipperID = shipperID;
		Date = date;
	}
	public Load() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getLoadingpoint() {
		return Loadingpoint;
	}
	public void setLoadingpoint(String loadingpoint) {
		Loadingpoint = loadingpoint;
	}
	public String getUnloadingpoint() {
		return Unloadingpoint;
	}
	public void setUnloadingpoint(String unloadingpoint) {
		Unloadingpoint = unloadingpoint;
	}
	public String getProductType() {
		return ProductType;
	}
	public void setProductType(String productType) {
		ProductType = productType;
	}
	public String getTruckType() {
		return TruckType;
	}
	public void setTruckType(String truckType) {
		TruckType = truckType;
	}
	public long getNoOfTrucks() {
		return NoOfTrucks;
	}
	public void setNoOfTrucks(long noOfTrucks) {
		NoOfTrucks = noOfTrucks;
	}
	public long getWeight() {
		return Weight;
	}
	public void setWeight(long weight) {
		Weight = weight;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public long getShipperID() {
		return ShipperID;
	}
	public void setShipperID(long shipperID) {
		ShipperID = shipperID;
	}
	public String getDate() {
		return Date;
	}
	public void setDate(String date) {
		Date = date;
	}
	@Override
	public String toString() {
		return "Load [Loadingpoint=" + Loadingpoint + ", Unloadingpoint=" + Unloadingpoint + ", ProductType="
				+ ProductType + ", TruckType=" + TruckType + ", NoOfTrucks=" + NoOfTrucks + ", Weight=" + Weight
				+ ", Description=" + Description + ", ShipperID=" + ShipperID + ", Date=" + Date + "]";
	}
	
	
	
}
