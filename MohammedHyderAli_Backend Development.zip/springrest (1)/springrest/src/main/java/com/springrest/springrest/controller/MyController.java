package com.springrest.springrest.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.springrest.springrest.entity.Load;
import com.springrest.springrest.services.LoadService;

@RestController
public class MyController {

	@Autowired
	private LoadService loadservice;

	//Adding loading details
	@PostMapping("/load")
	public Load addloaddetails(@RequestBody Load load) {
		return this.loadservice.addloaddetails(load);
	}
	
	//Get loading details
	@GetMapping("/load")
	public List<Load> getloaddetails(){
		return this.loadservice.getloaddetails();
	}
	
	// Get load details for given shipperID
	@GetMapping("/load/{shipperID}")
	public Load getloaddetail(@PathVariable String shipperID) {
		return this.loadservice.getloaddetail(Long.parseLong(shipperID));
	}
	
	//Updating the loading details present in the database
	@PutMapping("/load/{shipperID}")
	public Load updateloaddetails(@RequestBody Load load) {
		return this.loadservice.updateloaddetails(load);
	}
	
	//Delete a load detail
	@DeleteMapping("/load/{shipperID}")
	public ResponseEntity<HttpStatus> deleteloaddetail(@PathVariable String shipperID){
		try {
			this.loadservice.deleteloaddetail(Long.parseLong(shipperID));
			return new ResponseEntity<>(HttpStatus.OK);
		}
		catch(Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
}
