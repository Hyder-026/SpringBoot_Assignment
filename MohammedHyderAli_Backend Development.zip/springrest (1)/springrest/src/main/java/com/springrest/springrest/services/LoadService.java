//Parent class for saving data to the database 

package com.springrest.springrest.services;

import java.util.List;

import com.springrest.springrest.entity.Load;

public interface LoadService {

	public Load addloaddetails(Load newload);
	
	public List<Load> getloaddetails();
	
	public Load getloaddetail(long shipperID);
	
	public Load updateloaddetails(Load load);
	
	public void deleteloaddetail(long shipperID);
	
}
