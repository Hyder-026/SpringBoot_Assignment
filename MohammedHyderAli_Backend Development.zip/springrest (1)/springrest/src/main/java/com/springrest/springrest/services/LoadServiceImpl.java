// Creating the child class so maintain close coupling to makes easily.

package com.springrest.springrest.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springrest.springrest.DataRepository.LoadRepository;
import com.springrest.springrest.entity.Load;

@Service
public class LoadServiceImpl implements LoadService {

	
	@Autowired
	private LoadRepository loadrepository;
	
	//Adding loading details to the database
	@Override
	public Load addloaddetails(Load newload) {
		
		return loadrepository.save(newload);
	}
	
	//Creating list to store the details
	List<Load> list;
	public LoadServiceImpl() {	

	}
	
	@Override
	public List<Load> getloaddetails() {

		return loadrepository.findAll();
	}

	// Find the given detail using shipperID
	@Override
	public Load getloaddetail(long shipperID) {

		return loadrepository.getById(shipperID);
	}

	//Updating the load detail using the shipperID and getter and setters
	@Override
	public Load updateloaddetails(Load load) {
		
		return loadrepository.save(load);
	}
	
	//Deleting the load detail by find it using shipperID
	@Override
	public void deleteloaddetail(long shipperID) {
		
		loadrepository.deleteById(shipperID);
	}

}
